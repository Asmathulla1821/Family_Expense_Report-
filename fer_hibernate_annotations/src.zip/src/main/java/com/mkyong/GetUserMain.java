package com.mkyong;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class GetUserMain {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");


		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		DBUser user = null;

		user = (DBUser) session.get(DBUser.class, 55);
		System.out.println("get 1");
		if (user != null) {
			System.out.println(user.getUsername() + ", " + user.getCreatedBy() + " and " + user.getCreatedDate());
		}
		user = (DBUser) session.get(DBUser.class, 55);
		System.out.println("get 2");
		if (user != null) {
			System.out.println(user.getUsername() + ", " + user.getCreatedBy() + " and " + user.getCreatedDate());
		}

		// 5. Close the session
		session.close();

	}
}
