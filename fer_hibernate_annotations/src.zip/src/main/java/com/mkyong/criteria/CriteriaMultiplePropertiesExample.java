package com.mkyong.criteria;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;

import com.mkyong.user.DBUser;

public class CriteriaMultiplePropertiesExample {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");

		new DBUser();

		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		Criteria criteria = session.createCriteria(DBUser.class);
		System.out.println("Criteria Created");

		ProjectionList projectionList = Projections.projectionList();

		// a. Create Projection object
		Projection idProjection = Projections.property("userId");
		Projection nameProjection = Projections.property("username");

		projectionList.add(idProjection);
		projectionList.add(nameProjection);

		// b. Add Projection object into Criteria
		criteria.setProjection(projectionList);

		List<Object[]> users = criteria.list();
		System.out.println("List object got created");

		Iterator<Object[]> iterator = users.iterator();
		System.out.println("Iterator got created");

		Object[] userArr = null;
		while (iterator.hasNext()) {
			userArr = iterator.next();
			System.out.println(userArr[0] + ", " + userArr[1]);
		}

		// 5. Close the session
		session.close();

	}
}
