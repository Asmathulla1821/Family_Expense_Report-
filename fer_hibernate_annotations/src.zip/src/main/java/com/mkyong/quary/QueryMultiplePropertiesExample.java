package com.mkyong.quary;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class QueryMultiplePropertiesExample {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");

		new DBUser();

		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		Query query = session.createQuery("select user.userId, user.username from DBUser user");
		System.out.println("Query Created");

		List<Object[]> users = query.list();
		System.out.println("List object got created");

		Iterator<Object[]> iterator = users.iterator();
		System.out.println("Iterator got created");

		Object[] userArr = null;
		while (iterator.hasNext()) {
			userArr = iterator.next();
			System.out.println(userArr[0] + ", " + userArr[1]);
		}

		// 5. Close the session
		session.close();

	}
}
