package com.mkyong.quary;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class QueryUpdateExample {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");


		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		Query query = session.createQuery("update DBUser u set u.grSalary=?, u.salary=?, version=version+1 where userId=?");
		System.out.println("Query Created");

		query.setParameter(0, 45000f);
		query.setParameter(1, 43000f);
		query.setParameter(2, 1);
		
		Transaction transaction = session.beginTransaction();
		int numberOfRecAffected = query.executeUpdate();
		System.out.println(numberOfRecAffected);

		transaction.commit();
		// 5. Close the session
		session.close();

	}
}
