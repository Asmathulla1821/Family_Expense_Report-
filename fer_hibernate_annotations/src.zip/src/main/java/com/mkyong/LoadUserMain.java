package com.mkyong;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class LoadUserMain {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");


		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		DBUser user = null;
		try {
			user = (DBUser) session.load(DBUser.class, 44);
			System.out.println("load 1");
			System.out.println(user.getUsername() + ", " + user.getCreatedBy() + " and " + user.getCreatedDate());
		} catch (ObjectNotFoundException onfe) {
			System.out.println(onfe.getMessage());
		}

		try {
			user = (DBUser) session.load(DBUser.class, 41);
			System.out.println("load 1");
			System.out.println(user.getUsername() + ", " + user.getCreatedBy() + " and " + user.getCreatedDate());
		} catch (ObjectNotFoundException onfe) {
			System.out.println(onfe.getMessage());
		}
		// 5. Close the session
		session.close();

	}
}
