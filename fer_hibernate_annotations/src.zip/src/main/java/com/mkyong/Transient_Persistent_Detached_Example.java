package com.mkyong;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class Transient_Persistent_Detached_Example {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");


		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();

		// 3. Open the session
		Session session = sessionFactory.openSession();

		// 4. Actual call
		// Transient
		DBUser user = null;

		// Persistent
		user = (DBUser) session.get(DBUser.class, 1);
		session.close();
		
		// Detached
		user.setUsername("Mahi");
		
		session = sessionFactory.openSession();
		session.update(user);
		Transaction transaction = session.beginTransaction();
		
		transaction.commit();

		// 5. Close the session
		session.close();

	}
}
