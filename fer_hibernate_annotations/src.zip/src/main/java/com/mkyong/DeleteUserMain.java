package com.mkyong;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mkyong.user.DBUser;

public class DeleteUserMain {
	public static void main(String[] args) {
		System.out.println("Maven + Hibernate + mysql");
		
		DBUser user = new DBUser();

		user.setUserId(7);

		// 1. Load the hibernate configuration
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		// 2. Built the session factory
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		// 3. Open the session 
		Session session = sessionFactory.openSession();
		
		// 4. Begin the transaction
		Transaction transaction = session.beginTransaction();
		
		// 5. Actual call
		session.delete(user);
		
		// 6. Commit the transaction
		transaction.commit();
		
		// 7. Close the session
		session.close();
		
	}
}
